const express = require('express')
const sql = require('mysql2');
const doenv = require("dotenv");
const cors = require('cors')

const app = express();
const port = 8080;

doenv.config({
    path:'./.env'
})

app.use(cors())
app.use(express.json())

const db = sql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASS,
    database: process.env.DATABASE,
});


db.connect((err)=>{
    if(err){
        console.log("mysql failed");
    }else{
        console.log("mysql success");
    }
});


app.get('/getEvent',async (req,res)=>{
 
  dbConnection.query('select * from events limit 10', (error, results, fields) => {
      if (error) throw error;
      console.log(results);
      return res.status(200).json({event:results})
    });

});


app.post("/event", (req, res) => {
  const newEvent = req.body;
  db.query(
    "INSERT INTO events (event_name,event_date,event_description,event_venue) VALUES (?, ?, ?,?)",
    [newEvent.event_name,newEvent.event_date,newEvent.event_description,newEvent.event_venue],
    (err, insertResults) => {
      console.log(newEvent);
      console.log(err)
      if (err) {
        console.log("500");
        res.status(500).send("Error inserting user details");
      } else {
        console.log("Event registered successfully");
        res.status(201).send("Event registered successfully");
      }
    }
  );
});

app.get('/api/birthday', (req, res) => {
  const currentMonth = new Date().getMonth() +1;
 
  const query = `
  SELECT * FROM user_details
  WHERE MONTH(dob) = ${currentMonth} AND DATE_FORMAT(dob, '%m-%d') = DATE_FORMAT(NOW(), '%m-%d')
  ORDER BY dob ASC
  `;

  // Execute the SQL query and handle the response

  db.query(query, (error, results) => { 
    if (error) {
      console.error('Error fetching data1111:', error);
      res.status(500).json({ error: 'Internal server error' });
    } else {
        console.log(results)
      res.json(results);
    }
  });
});

app.get('/api/data', (req, res) => {

  const query = 'SELECT * FROM public_holidays ';

    db.query(query, (err, results) => {
      if (err) {
        res.status(500).json({ error: 'Error fetching data from database' });
      } else {
        res.status(200).json({results});
        console.log(results);
      }
    });
  });

app.get('/api/data', (req, res) => {
    const query = 'SELECT project_name,start_date,end_date,project_description,team_lead FROM project_allocation';
    db.query(query, (err, results) => {
      if (err) {
        res.status(500).json({ error: 'Error fetching data from database' });
      } else {
        res.status(200).json(results);
      }
    });
  });

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
  });