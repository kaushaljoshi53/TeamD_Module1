import React, { useState } from 'react';

function EventCard({ events }) {

  
  const [currentIndex, setCurrentIndex] = useState(0);

  const previousEvent = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const nextEvent = () => {
    if (currentIndex < events.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };
  

  const event = events[currentIndex];
  return (
    <div className="event-component">
      <h2>Upcoming Event</h2>
      {event && (
        <div className="event-card">
          <h3>{event.event_name}</h3>
          <p> {event.event_date}</p>
          <p>{event.event_description}</p>
        </div>
      )}
      <div className="navigation-buttons">
        <button onClick={previousEvent} disabled={currentIndex === 0}>
          Previous Event
        </button>
        <button onClick={nextEvent} disabled={currentIndex === events.length - 1}>
          Next Event
        </button>
      </div>
    </div>
  );
}

export default EventCard;