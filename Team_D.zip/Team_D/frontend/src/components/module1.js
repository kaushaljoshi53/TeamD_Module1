import React from 'react';
import Dashboard from './dashboard';
import Project from './project';
import Birthday from './birthday';
import Event_admin from './event_admin';
import Event_user from './event';
import Holiday from './holiday';
import EventCard from './event_card';
import './module.css'

function Module(){
    return(
        <div className='modules'>
            {/* <Dashboard/> */}
            
            
            <div className='right'>
            {/* <Event_user/> */}
            {/* <Event_admin/> */}
            <Project/>
            {/* <Birthday/> */}
            </div>
        </div>
    )
}

export default Module;