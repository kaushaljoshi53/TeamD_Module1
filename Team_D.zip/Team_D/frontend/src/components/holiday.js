//import React components and libraries
import React,{useEffect, useState} from "react";
import axios from 'axios';

//Main function
const Holiday = () => {
  //React Hooks for storing and handling events
    const [activeStep, setActiveStep] = useState(0);

    const handleNext = () => {
      setActiveStep((prevActiveStep) => prevActiveStep + 1);
    };
  
    const handleBack = () => {
      setActiveStep((prevActiveStep) => prevActiveStep - 1);
    };

    const [holiday, setHoliday] = useState([]);

    //Hooks for Side effect generation
    useEffect(() => {
        fetchData();
    }, []);

    //Fething data from database and displaying to F.E.
    const fetchData = async () => {
        try {
            const responsed = await axios.get('http://localhost:8080/api/data');
            console.log(responsed);
            const jsonData = responsed.data.results;
            setHoliday(jsonData);
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    //Creating array of response result from B.E.
    const MyCollection = holiday.map((item) => ({
      h_id: item.h_id,
      occation: item.occation,
      date: item.date,
      description: item.description,
      // image: item.image
    }));
  
    //Styling of main parent div ->for easier understanding of child css
    const styles = {
      display: 'flex',
      flexDirection:'column',
       marginTop:100 ,
       width:350,
       height:350,
       border: '1px solid lightgrey',
       margin:50,
       padding:4,
       borderRadius:4,
       maxWidth: '50%',
       minWidth: '80px',
       minHeight: '100px',
       padding: '20px 40px',
       borderRadius: '6px',
       boxShadow: '0px 8px 36px #222',
       background: '#fefefe',
       width: '250px',
       
 };
  


	return (
		<div>
      {/* //Holiday Component */}
      <div style={styles}>

        {/* Heading Component */}
        <h3 style={{ margin:1,
                      padding:6 ,
                      border: '1px solid black',
                      borderRadius:4,
                      fontFamily: "Arial" ,
                      background:'#19105B',
                      marginRight:0,
                      width:'94%',
                      minWidth: '50%',
                      color:'white' }}>
          Upcoming Holidays</h3>
          
        {/* Holiday Element Div */}
        <div style={{ width: '100%' ,
                      height:'100%',
                      marginTop:4,
                      borderRadius:4}}>
          <img
            src={"https://picsum.photos/300/300"}
            alt={''}
            style={{ width: '100%', height: '40%' ,justifyContent:'space-evenly',borderRadius:6}}
          />

        {/* Holiday Name */}
        <div style={{marginTop:6,
                    background:'#FBBFD3',
                    fontSize:'12.5px',
                    color:'#19105B',
                    fontWeight:'bold',
                    padding:6,
                    borderRadius:6}}>
        {MyCollection[activeStep].occation+' '+MyCollection[activeStep].date}
      </div>

          {/* Holiday description */}
      <div style={{marginTop:6,
                  height:'25%',
                  background:'#FFE5EE',
                  fontSize:'14.5px',
                  border:'1px solid #FFE5EE',
                  borderRadius:6 }}>
      {MyCollection[activeStep].description}
        </div>
          
        {/* Previous Next Buttons */}
        <div style={{ display: 'flex', 
                      justifyContent: 'center',
                      marginTop: 8}}>
          <button
            onClick={handleBack}
            disabled={activeStep === 0}
            style={{marginRight: 16,
                    background:'#ff326b',
                    border: '1px solid hotpink',
                    borderRadius:4,
                    color:'white',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: '60px',
                    height: '20px',
                    color: '#ffffff',
                    fontSize: '11.5px',
                    fontWeight: 300,
                    textTransform: 'capitalize',
                    borderRadius: '3px' }}
          >
            Previous
          </button>

          <button
            onClick={handleNext}
            disabled={activeStep === MyCollection.length - 1}
            style={{background:'#ff326b',border: '1px solid hotpink',borderRadius:4,color:'white'  }}
          >
            Next
          </button>
        </div>
        </div>
</div>

    </div>
  );
};
export default Holiday;