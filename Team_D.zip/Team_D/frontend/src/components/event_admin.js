import React, { useState } from 'react';
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import './event_admin.css';
import Holiday from './holiday';
import EventCard from './event_card';

function Event_admin() {
  const [event_name, setEventName] = useState('');
  const [event_date, setEventDate] = useState('');
  const [event_description, setEventDes] = useState('');
  const [event_venue, setEventVenue] = useState('');
  const addEvent = () => {

  const newEvent = {
    
     event_name,
    event_date,
    event_description,
     event_venue,
  };
  axios.post("http://localhost:8080/event", newEvent)
  .then((response) => {
      console.log(response.data);
      if (response.status === 201) {
          alert("Registered Successfully");
      } else {
          alert("Error")
      }
  })
  .catch((error) => {
      // console.error("Error during API call:", error);
      alert("Please enter valid credentials");
  });
  }
  return (
    <>

        {/* Content Area */}
        <div className="col-10" style={{ paddingLeft: '120px', paddingTop: '10px' }}>
          <div className="container" style={{ marginLeft: '110px' }}>
            {/* Page title */}
            
            <button
              type="button"
              className="btn btn-primary"
              data-bs-toggle="modal"
              data-bs-target="#createEventModal"
            >
              Create Event
            </button>
            {/* Create Event Modal */}
            <div
              className="modal fade"
              id="createEventModal"
              tabIndex="-1"
              aria-labelledby="exampleModalLabel"
              aria-hidden="true"
            >
              <div className="modal-dialog">
                <div className="modal-content">
                  <div className="modal-header">
                    <h5 className="modal-title" id="exampleModalLabel">
                      Create Event
                    </h5>
                    <button
                      type="button"
                      className="btn-close"
                      data-bs-dismiss="modal"
                      aria-label="Close"
                    ></button>
                  </div>
                  <div className="modal-body">

                    <input
                      type="text"
                      placeholder="Event Name"
                       name={event_name}
                      onChange={(e) => setEventName(e.target.value)}
                    />
                    <input
                      type="date"
                      placeholder="Event Date"
                      date={event_date}
                      onChange={(e) => setEventDate(e.target.value)}
                    />
                    <div className="description-wrapper">
                      <input
                        type="text"
                        placeholder="Event Description"
                        des={event_description}
                        onChange={(e) => setEventDes(e.target.value)}
                      />
                    </div>
                    <input
                      type="text"
                      placeholder="Event Venue"
                      venu={event_venue}
                      onChange={(e) => setEventVenue(e.target.value)}
                    />
                  </div>

                  <div className="modal-footer">
                    <button
                      type="button"
                      className="btn btn-secondary"
                      data-bs-dismiss="modal"
                    >
                      Close
                    </button>
                    <button
                      type="button"
                      className="btn btn-primary"
                      onClick={addEvent}
                    >
                      Create
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      
    
    </>
  );
}


export default Event_admin;

