import EventCard from './event_card';
import './App.css';
import axios from 'axios';
import { useEffect, useState } from 'react';



function Event_user() {


  const [eventsData, seteventsData] = useState([])

  useEffect(()=>{
    async function getEvent(){
      const data1 = await axios.get('http://localhost:8080/getEvent')
      const eventsData =  data1.data.event
      console.log(eventsData);
      seteventsData(eventsData)

    }
    getEvent()
  },[])




  return (
    <div className="App">
      
      <EventCard events={eventsData}/>
    </div>
  );
}

export default Event_user;