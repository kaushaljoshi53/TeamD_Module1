import { BrowserRouter,Routes,Route } from 'react-router-dom';
import Login from './login';
import Dashboard from './dashboard';
import Project from './project';
import Birthday from './birthday';
import Event_admin from './event_admin';
import Event_user from './event';
import Holiday from './holiday';
import EventCard from './event_card';
import Module from './module1';




function App() {
  return (


    

    
    <BrowserRouter>
      <Routes>
        
        <Route path="/" element={<Module/>} />


        
        
        
      </Routes>
    </BrowserRouter>
  );
}

export default App;
