import React from "react";

function Login(){
    return(
        <div>
            <p>Hi</p>
        </div>
    )
}

export default Login;